package com.example.susie.suesshopper;

import android.content.Context;
import android.database.Cursor;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;

/**
 * The ShoppingListItems class will map the data selected from the shopping list item table
 * to the ListView in the ViewList activity.
 */
public class ShoppingListItems extends CursorAdapter {

    /**
     * Initializes ShoppingListItems CursorAdapter.
     * @param context reference to activity that initialized the CursorAdapter
     * @param cursor reference to Cursor that contains data from database
     * @param flags determines special behavior of the CursorAdapter. Will always be 0 which
     *              means the Cursor shouldn't have any special behavior.
     */
    public ShoppingListItems (Context context, Cursor cursor, int flags){
        super(context, cursor, flags);
    }

    /**
     * Makes a new View to hold the data in Cursor.  I believe this method is getting called
     * at some point when setAdapter is called on itemsListView.
     * @param context reference to activity that initialized the CursorAdapter
     * @param cursor reference to Cursor that contains data from database
     * @param viewGroup reference to itemsListView that will contain the newView
     * @return reference to new View
     */
    @Override
    public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
        return null;
    }

    /**
     * Binds new View to the data in cursor.  I believe this method is getting called
     * at some point when setAdapter is called on itemsListView.
     * @param view new View just created
     * @param context reference to activity that initialized the CursorAdapter
     * @param cursor reference to Cursor that contains data from database
     */
    @Override
    public void bindView(View view, Context context, Cursor cursor) {

    }
}
