package com.example.susie.suesshopper;

/**
 * The ShoppingListItem class will store the data selected by the getShoppingListItem
 * DBHandler method.
 */
public class ShoppingListItem {

}
