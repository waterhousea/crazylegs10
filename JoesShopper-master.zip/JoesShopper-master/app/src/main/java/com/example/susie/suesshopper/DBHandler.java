package com.example.susie.suesshopper;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHandler extends SQLiteOpenHelper {

    // initialize constants for DB version and name
    private static final int DATABASE_VERSION = 2;
    private static final String DATABASE_NAME = "shopper.db";

    // initialize constants for shoppinglist table
    public static final String TABLE_SHOPPING_LIST = "shoppinglist";
    public static final String COLUMN_LIST_ID = "_id";
    public static final String COLUMN_LIST_NAME = "name";
    public static final String COLUMN_LIST_STORE = "store";
    public static final String COLUMN_LIST_DATE = "date";

    // initialize constants for shoppinglistitem table
    public static final String TABLE_SHOPPING_LIST_ITEM = "shoppinglistitem";
    public static final String COLUMN_ITEM_ID = "_id";
    public static final String COLUMN_ITEM_NAME = "name";
    public static final String COLUMN_ITEM_PRICE = "price";
    public static final String COLUMN_ITEM_QUANTITY = "quantity";
    public static final String COLUMN_ITEM_HAS = "item_has";
    public static final String COLUMN_ITEM_LIST_ID = "list_id";

    /**
     * Initializes a DBHandler.  Creates version of the database.
     * @param context reference to activity that initializes the DBHandler
     * @param factory null
     */
    public DBHandler (Context context, SQLiteDatabase.CursorFactory factory){
        // call superclass constructor
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    /**
     * Creates database tables
     * @param sqLiteDatabase reference to shopper database
     */
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        // define create statement for shopping list table
        String query = "CREATE TABLE " + TABLE_SHOPPING_LIST + "(" +
                COLUMN_LIST_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_LIST_NAME + " TEXT, " +
                COLUMN_LIST_STORE + " TEXT, " +
                COLUMN_LIST_DATE + " TEXT" +
                ");";

        // execute create statement
        sqLiteDatabase.execSQL(query);

        // define create statement for shopping list item table
        String query2 = "CREATE TABLE " + TABLE_SHOPPING_LIST_ITEM + "(" +
                COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_ITEM_NAME + " TEXT, " +
                COLUMN_ITEM_PRICE + " DECIMAL(10,2), " +
                COLUMN_ITEM_QUANTITY + " INTEGER, " +
                COLUMN_ITEM_HAS + " TEXT, " +
                COLUMN_ITEM_LIST_ID + " INTEGER" +
                ");";

        // execute create statement
        sqLiteDatabase.execSQL(query2);
    }

    /**
     * This method gets executed when a new version of the database is initialized.
     * @param sqLiteDatabase reference to shopper database
     * @param oldVersion old version of database
     * @param newVersion new version of database
     */
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {

        // execute drop statement that drops shopping list table
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_SHOPPING_LIST);

        // execute drop statement that drops shopping list item table
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_SHOPPING_LIST_ITEM);

        // call method that creates tables
        onCreate(sqLiteDatabase);
    }

    /**
     * This method gets called when the add Item in the CreateList Menu gets clicked.
     * It inserts a new row in the shopping list table.
     * @param name shopping list name
     * @param store shopping list store
     * @param date shopping list date
     */
    public void addShoppingList (String name, String store, String date) {

    }

    /**
     * This method gets called when the Main activity is created.
     * @return Cursor that contains all rows in shopping list table
     */
    public Cursor getShoppingLists () {
        return null;
    }

    /**
     * This method gets called when the ViewList activity is created.
     * @param id shopping list id
     * @return shopping list name
     */
    public String getShoppingListName (int id){
        return "";
    }

    /**
     * This method gets called when the add Item in the CreateItem Menu gets clicked.
     * It inserts a new row in the shopping list item table.
     * @param name item name
     * @param price item price
     * @param quantity item quantity
     * @param listId shopping list id that item is being added to
     */
    public void addItemToList (String name, Double price, Integer quantity, Integer listId) {

    }

    /**
     * This method gets called when the ViewList activity is created.
     * @param listId shopping list id
     * @return Cursor that contains all of the items associated with
     * the shopping list id
     */
    public Cursor getShoppingListItems (Integer listId) {
        return null;
    }

    /**
     * This method gets called when a shopping list item is clicked in the ViewList
     * activity.
     * @param itemId shopping list item id
     * @return 1 if item_has equals false, else 0
     */
    public int isItemUnpurchased (Integer itemId){
        return 1;
    }

    /**
     * This method gets called when a shopping list item is clicked in the ViewList
     * activity.
     * @param itemId shopping list item id
     */
    public void updateItem (Integer itemId){

    }

    /**
     * This method gets called when a shopping list item is clicked in the ViewList
     * activity.
     * @param listId shopping list id
     * @return 0 if all items on list have an item_has of true, else the number
     * of items that have an item_has of false
     */
    public int getUnpurchasedItems (Integer listId) {
        return 1;
    }

    /**
     * This method gets called when the ViewItem activity is created.
     * @param itemId shopping list item id
     * @return ShoppingListItem that contains information about the specified
     * shopping list item id
     */
    public ShoppingListItem getShoppingListItem (Integer itemId){
        return null;
    }

    /**
     * This method gets called when the delete Item in the ViewList Menu is clicked.
     * @param itemId shopping list item id
     */
    public void deleteShoppingListItem (Integer itemId){

    }

    /**
     * This method gets called with the delete Item in the Main Menu is clicked.
     * @param listId shopping list id
     */
    public void deleteShoppingList (Integer listId){

    }

    /**
     * This method gets called when the ViewList activity is created.
     * @param listId shopping list id
     * @return total cost of all items on specified shopping list
     */
    public String getShoppingListTotalCost (Integer listId){
        return "";
    }
}
