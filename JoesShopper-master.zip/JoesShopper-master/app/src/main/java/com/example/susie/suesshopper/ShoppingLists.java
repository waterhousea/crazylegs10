package com.example.susie.suesshopper;

import android.content.Context;
import android.database.Cursor;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;

/**
 * The ShoppingLists class will map the data selected from the shopping list table
 * to the li_shopping_list layout resource
 */
public class ShoppingLists extends CursorAdapter {

    /**
     * Initializes ShoppingLists CursorAdapter.
     * @param context reference to activity that initialized the CursorAdapter
     * @param cursor reference to Cursor that contains data from database
     * @param flags determines special behavior of the CursorAdapter. Will always be 0 which
     *              means the Cursor shouldn't have any special behavior.
     */
    public ShoppingLists (Context context, Cursor cursor, int flags) {
        super(context, cursor, flags);
    }

    /**
     * Makes a new View to hold the data in Cursor.  I believe this method is getting called
     * at some point when setAdapter is called on shopperListView.
     * @param context reference to activity that initialized the CursorAdapter
     * @param cursor reference to Cursor that contains data from database
     * @param viewGroup reference to shopperListView that will contain the newView
     * @return reference to new View
     */
    @Override
    public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
        return null;
    }

    /**
     * Binds new View to the data in cursor.  I believe this method is getting called
     * at some point when setAdapter is called on shopperListView.
     * @param view new View just created
     * @param context reference to activity that initialized the CursorAdapter
     * @param cursor reference to Cursor that contains data from database
     */
    @Override
    public void bindView(View view, Context context, Cursor cursor) {

    }
}
