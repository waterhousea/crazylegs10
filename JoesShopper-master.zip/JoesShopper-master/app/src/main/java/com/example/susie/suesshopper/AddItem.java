package com.example.susie.suesshopper;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;

public class AddItem extends AppCompatActivity {

    /**
     * This method initializes the AddItem Activity.
     * @param savedInstanceState a Bundle object that is passed into the onCreate
     *                           method of every Android Activity. Activities have
     *                           the ability, under special circumstances, to restore
     *                           themselves to a previous state using the data stored
     *                           in this bundle. If there is no available instance data,
     *                           the savedInstanceState will be null.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {

    }

    /**
     * This method gets called when the add Item in the Menu
     * gets pushed.  It validates that all required data has been input.
     * If it has been input, it adds it to the database and displays a Toast,
     * else it simply displays a Toast.
     * @param menuItem because the add Item that calls this method is
     *             in a Menu, we must pass the method a MenuItem.
     */
    public void addItem (MenuItem menuItem) {

    }

    /**
     * This method inflates (creates) the overflow menu for the AddItem Activity.
     * @param menu menu_add_item
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    /**
     * This method gets called when an item in the overFlow menu is selected.
     * @param item selected item; contains information about the item
     *             selected; for example, the id
     * @return true if item selected; else false
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }
}
