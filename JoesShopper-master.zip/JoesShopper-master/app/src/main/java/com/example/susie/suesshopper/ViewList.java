package com.example.susie.suesshopper;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class ViewList extends AppCompatActivity {

    /**
     * This method initializes the ViewList Activity.
     * @param savedInstanceState a Bundle object that is passed into the onCreate
     *                           method of every Android Activity. Activities have
     *                           the ability, under special circumstances, to restore
     *                           themselves to a previous state using the data stored
     *                           in this bundle. If there is no available instance data,
     *                           the savedInstanceState will be null.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {

    }

    /**
     * This method inflates (creates) the overflow menu for the ViewList Activity.
     * @param menu menu_view_list
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    /**
     * This method gets called when an item in the overFlow menu is selected.
     * @param item selected item; contains information about the item
     *             selected; for example, the id
     * @return true if item selected; else false
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    /**
     * This method gets called when the add FloatingActionButton is clicked.
     * It starts the ViewItem activity.
     * @param view because the FloatingActionButton that calls this method is
     *             in a View, we must pass the method a View.
     */
    public void openAddItem (View view){

    }

    /**
     * This method gets called when the delete Item in the Menu
     * gets pushed.  It deletes the shopping list from the database and
     * displays a Toast.
     * @param menuItem because the delete Item that calls this method is
     *             in a Menu, we must pass the method a MenuItem.
     */
    public void deleteShoppingList (MenuItem menuItem) {

    }

    /**
     * This method gets called when a shopping list item is clicked.  If
     * the item hasn't been put in the cart, it updates its item_has to true
     * and displays a Toast indicating the item is now in the cart.  If all
     * items on the shopping list are in the cart, it posts a notification.
     * @param id shopping list item id
     */
    public void updateItem(long id){

    }

}
